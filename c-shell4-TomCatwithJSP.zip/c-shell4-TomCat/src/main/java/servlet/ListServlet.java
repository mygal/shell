/**
 * 
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ListServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("name");
		String password = req.getParameter("pass");
		
		List<String> parcels = model.list(); // А посылок то много, у одного юзера...
		req.setAttribute("parcelId", id);
		req.setAttribute("cargo_status", id);
		req.setAttribute("consignee_name", id);
		req.setAttribute("destination_address", id);
		
		parcel.setCargo_status(cargo_status);
		parcel.setConsignee_name(req.getParameter("consignee_name"));
		parcel.setSource_address(req.getParameter("source_address"));
		parcel.setDestination_address(req.getParameter("destination_address"));
		

		RequestDispatcher requestDispatcher = req.getRequestDispatcher("views/list.jsp");
		requestDispatcher.forward(req, resp);
	}
}
