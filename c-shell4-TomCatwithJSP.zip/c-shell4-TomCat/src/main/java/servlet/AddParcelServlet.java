/**
 * 
 */
package servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Parcel;
import bean.UserAccount;
import utils.DataDAO;

public class AddParcelServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("views/addParcel.jsp");
		requestDispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String password = req.getParameter("pass");
		
		// TODO заплатка из ДАО - переделать когда будет БД.
		UserAccount user = DataDAO.findUser(name, password);

		Parcel parcel = new Parcel(user);
		
		//TODO написать проверку входных данных (пустые поля)
		String cargo_status = "Waiting for shipment";
		parcel.setCargo_status(cargo_status);
		parcel.setConsignee_name(req.getParameter("consignee_name"));
		parcel.setSource_address(req.getParameter("source_address"));
		parcel.setDestination_address(req.getParameter("destination_address"));

		long parcelNum = DataDAO.addUserParcel(parcel);

		req.setAttribute(Long.toString(parcelNum), parcel);
		doGet(req, resp);
	}
}
