package utils;

import java.util.HashMap;
import java.util.Map;

import bean.Parcel;
import bean.UserAccount;
import config.SecurityConfig;

public class DataDAO {

	private static final Map<String, UserAccount> mapUsers = new HashMap<String, UserAccount>();
	
	// @OneToMany
	private static final HashMap<Long, Parcel> mapParcels = new HashMap<Long, Parcel>();
	
	private static long parcelsNumber = 0;

	static {
		initUsers();
	}

	private static void initUsers() {

		/* TODO Think about ROLES */

		// This user has a role as EMPLOYEE. ??????????
		UserAccount cargoOwner = new UserAccount("OWNER", "123", UserAccount.CARGO_OWNER,
				SecurityConfig.ROLE_CARGO_OWNER);

		// This user has 2 roles EMPLOYEE and MANAGER.???????????
		UserAccount logisticsCompany = new UserAccount("LOGISTICS COMPANY", "123", UserAccount.LOGISTICS_COMPANY,
				SecurityConfig.ROLE_LOGISTICS_COMPANY, SecurityConfig.ROLE_LOGISTICS_COMPANY);

		// This user has 2 roles EMPLOYEE and MANAGER.????????????????
		UserAccount cargoCarrier = new UserAccount("CARRIER", "123", UserAccount.CARRIER_OF_CARGO,
				SecurityConfig.ROLE_CARRIER_OF_CARGO, SecurityConfig.ROLE_CARRIER_OF_CARGO);

		mapUsers.put(cargoOwner.getUserName(), cargoOwner);
		mapUsers.put(logisticsCompany.getUserName(), logisticsCompany);
		mapUsers.put(cargoCarrier.getUserName(), cargoCarrier);
	}

	// Find a User by userName and password.
	public static UserAccount findUser(String userName, String password) {
		UserAccount u = mapUsers.get(userName);
		if (u != null && u.getPassword().equals(password)) {
			return u;
		}
		return null;
	}

	// Add a Parcel and set Id.
	public static long addUserParcel(Parcel parcel) {
		parcel.setId(++parcelsNumber);
		mapParcels.put(parcelsNumber, parcel);
		UserAccount user = parcel.getCargo_owner();
		user.addParcelsToList(parcel);
		return parcelsNumber;

	}

}