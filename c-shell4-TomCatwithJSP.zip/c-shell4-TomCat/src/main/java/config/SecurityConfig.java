package config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
 
public class SecurityConfig {
 
    public static final String ROLE_CARGO_OWNER = "CARGO_OWNER";
    public static final String ROLE_LOGISTICS_COMPANY = "LOGISTICS_COMPANY";
    public static final String ROLE_CARRIER_OF_CARGO = "CARRIER_OF_CARGO";
 
    // String: Role
    // List<String>: urlPatterns.
    private static final Map<String, List<String>> mapConfig = new HashMap<String, List<String>>();
 
    static {
        init();
    }
 
    private static void init() {
 
        // Конфигурация для роли "CARGO_OWNER".
        List<String> urlPatterns1 = new ArrayList<String>();
 
        urlPatterns1.add("/userInfo");
        urlPatterns1.add("/cargo_owner");
 
        mapConfig.put(ROLE_CARGO_OWNER, urlPatterns1);
 
        // Конфигурация для роли "LOGISTICS_COMPANY".
        List<String> urlPatterns2 = new ArrayList<String>();
 
        urlPatterns2.add("/userInfo");
        urlPatterns2.add("/logistics_company");
 
        mapConfig.put(ROLE_LOGISTICS_COMPANY, urlPatterns2);
        
        // Конфигурация для роли "CARRIER_OF_CARGO".
        List<String> urlPatterns3 = new ArrayList<String>();
 
        urlPatterns3.add("/userInfo");
        urlPatterns3.add("/carrier_of_cargo");
 
        mapConfig.put(ROLE_CARRIER_OF_CARGO, urlPatterns3);
        
    }
 
    public static Set<String> getAllAppRoles() {
        return mapConfig.keySet();
    }
 
    public static List<String> getUrlPatternsForRole(String role) {
        return mapConfig.get(role);
    }
 
}