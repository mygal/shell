package bean;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * 1st User (CARGO OWNER) - тот кто пересылает пакеты и может видеть прогресс
 * пересылки. 
 * 2nd User (LOGISTICS COMPANY) - фирма которая координирует мелких
 * локальных перевозчиков. Она может видеть больше всех данных. 
 * 3th User
 * (CARRIER_OF_CARGO) - локальный перевозчик. Он выставляет свои сервисы на биржу, User 2
 * бронирует его и назначает ему локальную перевозку.
 * 
 * Трекинг отосланных заказов. Список операторов перевозок и несколько
 * координаторов.
 */

public class UserAccount {

	// TODO Поле для отображения статуса, на чистовик можно убирать
	public static final String CARGO_OWNER = "CO";
	public static final String LOGISTICS_COMPANY = "LC";
	public static final String CARRIER_OF_CARGO = "CC";

	private String userName;
	private String position;
	private String password;

	private List<Parcel> parcels;

	private List<String> roles;

	public UserAccount() {

	}

	public UserAccount(String userName, String password, String position, String... roles) {
		this.userName = userName;
		this.password = password;
		this.position = position;

		this.roles = new ArrayList<String>();
		if (roles != null) {
			for (String r : roles) {
				this.roles.add(r);
			}
		}
				
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<Parcel> getParcelsList() {
		return parcels;
	}

	public void addParcelsToList(Parcel parcel) {
		parcels.add(parcel);
	}

	public int getNumOfParcels() {
		if (parcels == null) {
			return 0;
		} else {
			return parcels.size();
		}		
	}

}