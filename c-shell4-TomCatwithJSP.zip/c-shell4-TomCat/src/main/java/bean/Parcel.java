package bean;

import java.util.List;

public class Parcel {
	
	// Владелец посылки
	private UserAccount cargo_owner;
	private long id;
	
	// Грузополучатель
	private String consignee_name;

	public String getConsignee_name() {
		return consignee_name;
	}

	public void setConsignee_name(String consignee_name) {
		this.consignee_name = consignee_name;
	}

	// адреса отправления и получения
	private String source_address;
	private String destination_address;
	
	//Информация по перевозу груза: где и кто перевозит.
	private String cargo_status;
	
	//Список компаний перевозящих груз.
	private List<UserAccount> listOflogisticsComp;

	// Минимальная информация про груз - его владелец. Все остальное - опции.
	public Parcel(UserAccount cargo_owner) {
		this.cargo_owner = cargo_owner;
	}

	
	
	public UserAccount getCargo_owner() {
		return cargo_owner;
	}

	public void setCargo_owner(UserAccount cargo_owner) {
		this.cargo_owner = cargo_owner;
	}

	public String getSource_address() {
		return source_address;
	}

	public void setSource_address(String source_address) {
		this.source_address = source_address;
	}

	public String getDestination_address() {
		return destination_address;
	}

	public void setDestination_address(String destination_address) {
		this.destination_address = destination_address;
	}

	public String getCargo_status() {
		return cargo_status;
	}

	public void setCargo_status(String cargo_status) {
		this.cargo_status = cargo_status;
	}

	public List<UserAccount> getListOflogisticsComp() {
		return listOflogisticsComp;
	}

	public void addToListOflogisticsComp(UserAccount logisticsComp) {
		this.listOflogisticsComp.add(logisticsComp);
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
}
