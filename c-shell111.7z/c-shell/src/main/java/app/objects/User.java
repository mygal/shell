package app.objects;

public class User {
	private String name;
	private String password;
	private String role;
	private String description;
	private Long id;
	private String imageUrl;

	public static final String NAME = "name";
	public static final String PASSWORD = "password";
	public static final String ROLE = "role";
	public static final String DESCRIPTION = "description";
	public static final String ID = "id";
	public static final String IMAGE_URL = "imageUrl";

	private User(Builder builder) {
		this.name = builder.name;
		this.password = builder.password;
		this.role = builder.role;
		this.description = builder.description;
		this.id = builder.id;
		this.imageUrl = builder.imageUrl;
	}

	// [START builder]
	public static class Builder {

		private String name;
		private String password;
		private String role;
		private String description;
		private Long id;
		private String imageUrl;

		public Builder name(String name) {
			this.name = name;
			return this;
		}

		public Builder password(String password) {
			this.password = password;
			return this;
		}

		public Builder role(String role) {
			this.role = role;
			return this;
		}

		public Builder description(String description) {
			this.description = description;
			return this;
		}

		public Builder id(Long id) {
			this.id = id;
			return this;
		}

		public Builder imageUrl(String imageUrl) {
			this.imageUrl = imageUrl;
			return this;
		}

		public User build() {
			return new User(this);
		}

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	// public void setId(Long id) { this.id = id; }

	public Long getId() {
		return id;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	// public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

	@Override
	public String toString() {
		return "User{" + "name='" + name + '\'' + ", password='" + password + '\'' + ", role='" + role + '}';
	}

	@Override
	public boolean equals(Object o) {

		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		User user = (User) o;

		if (name != null ? !name.equals(user.name) : user.name != null)
			return false;

		return role != null ? role.equals(user.role) : user.role == null;

	}

	@Override
	public int hashCode() {
		int result = name != null ? name.hashCode() : 0;
		result = 31 * result + (role != null ? role.hashCode() : 0);
		return result;
	}
}