
package app.objects;

public class Parcel {
	// [START parcel]
	private String title;
	private String owner;
	private String startFrom;
	private String destination;
	private String description;
	private String imageUrl;
	private Long id;
	// [END parcel]
	// [START keys]
	public static final String TITLE = "title";
	public static final String OWNER = "owner";
	public static final String START_FROM = "startFrom";
	public static final String DESTINATION = "destination";
	public static final String DESCRIPTION = "description";
	public static final String IMAGE_URL = "imageUrl";
	public static final String ID = "id";
	// [END keys]

	// We use a Builder pattern here to simplify and standardize construction of
	// Parcel objects.
	private Parcel(Builder builder) {
		this.title = builder.title;
		this.owner = builder.owner;
		this.startFrom = builder.startFrom;
		this.destination = builder.destination;
		this.description = builder.description;
		this.id = builder.id;
		this.imageUrl = builder.imageUrl;
	}

	// [START builder]
	public static class Builder {
		private String title;
		private String owner;
		private String startFrom;
		private String destination;
		private String description;
		private Long id;
		private String imageUrl;

		public Builder title(String title) {
			this.title = title;
			return this;
		}

		public Builder owner(String owner) {
			this.owner = owner;
			return this;
		}

		public Builder startFrom(String startFrom) {
			this.startFrom = startFrom;
			return this;
		}

		public Builder destination(String destination) {
			this.destination = destination;
			return this;
		}

		public Builder description(String description) {
			this.description = description;
			return this;
		}

		public Builder id(Long id) {
			this.id = id;
			return this;
		}

		public Builder imageUrl(String imageUrl) {
			this.imageUrl = imageUrl;
			return this;
		}

		public Parcel build() {
			return new Parcel(this);
		}
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getStartFrom() {
		return startFrom;
	}

	public void setStartFrom(String startFrom) {
		this.startFrom = startFrom;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getId() {
		return id;
	}

	// public void setId(Long id) {	this.id = id; }

	public String getImageUrl() {
		return imageUrl;
	}

	//public void setImageUrl(String imageUrl) {this.imageUrl = imageUrl;}

	// [END builder]
	@Override
	public String toString() {
		return "Title: " + title + ", Owner: " + owner + ", Added by: " + startFrom;
	}
}
