/* Copyright 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package app.daos;

import app.objects.Parcel;
import app.objects.Result;

import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.SortDirection;
import com.google.appengine.api.datastore.QueryResultIterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// [START example]
public class DatastoreParcelDao implements ParcelDao {

	// [START constructor]
	private DatastoreService datastore;
	private static final String PARCEL_KIND = "Parcel2";

	public DatastoreParcelDao() {
		datastore = DatastoreServiceFactory.getDatastoreService(); // Authorized Datastore service
	}
	// [END constructor]

	// [START entityToParcel]
	public Parcel entityToParcel(Entity entity) {
		return new Parcel.Builder() // Convert to Parcel form
				.title((String) entity.getProperty(Parcel.TITLE)).owner((String) entity.getProperty(Parcel.OWNER))
				.startFrom((String) entity.getProperty(Parcel.START_FROM))
				.destination((String) entity.getProperty(Parcel.DESTINATION))
				.description((String) entity.getProperty(Parcel.DESCRIPTION))
				.imageUrl((String) entity.getProperty(Parcel.IMAGE_URL)).id(entity.getKey().getId()).build();
	}
	// [END entityToParcel]

	// [START create]
	@Override
	public Long createParcel(Parcel parcel) {
		Entity incParcelEntity = new Entity(PARCEL_KIND); // Key will be assigned once written

		incParcelEntity.setProperty(Parcel.TITLE, parcel.getTitle());
		incParcelEntity.setProperty(Parcel.OWNER, parcel.getOwner());
		incParcelEntity.setProperty(Parcel.START_FROM, parcel.getStartFrom());
		incParcelEntity.setProperty(Parcel.DESTINATION, parcel.getDestination());
		incParcelEntity.setProperty(Parcel.DESCRIPTION, parcel.getDescription());
		incParcelEntity.setProperty(Parcel.IMAGE_URL, parcel.getImageUrl());

		Key parcelKey = datastore.put(incParcelEntity); // Save the Entity
		return parcelKey.getId(); // The ID of the Key
	}
	// [END create]

	// [START read]
	@Override
	public Parcel readParcel(Long parcelId) {
		try {
			Entity parcelEntity = datastore.get(KeyFactory.createKey(PARCEL_KIND, parcelId));
			return entityToParcel(parcelEntity);
		} catch (EntityNotFoundException e) {
			return null;
		}
	}
	// [END read]

	// [START update]
	@Override
	public void updateParcel(Parcel parcel) {
		Key key = KeyFactory.createKey(PARCEL_KIND, parcel.getId()); // From a parcel, create a Key
		Entity entity = new Entity(key); // Convert Parcel to an Entity
		entity.setProperty(Parcel.TITLE, parcel.getTitle());
		entity.setProperty(Parcel.OWNER, parcel.getOwner());
		entity.setProperty(Parcel.START_FROM, parcel.getStartFrom());
		entity.setProperty(Parcel.DESTINATION, parcel.getDestination());
		entity.setProperty(Parcel.DESCRIPTION, parcel.getDescription());
		entity.setProperty(Parcel.IMAGE_URL, parcel.getImageUrl());

		datastore.put(entity); // Update the Entity
	}
	// [END update]

	// [START delete]
	@Override
	public void deleteParcel(Long parcelId) {
		Key key = KeyFactory.createKey(PARCEL_KIND, parcelId); // Create the Key
		datastore.delete(key); // Delete the Entity
	}
	// [END delete]

	// [START entitiesToParceles]
	public List<Parcel> entitiesToParceles(Iterator<Entity> results) {
		List<Parcel> resultParcels = new ArrayList<>();
		while (results.hasNext()) { // We still have data
			resultParcels.add(entityToParcel(results.next())); // Add the Parcel to the List
		}
		return resultParcels;
	}
	// [END entitiesToParceles]

	// [START listParceles]
	@Override
	public Result<Parcel> listParceles(String startCursorString) {
		FetchOptions fetchOptions = FetchOptions.Builder.withLimit(10); // Only show 10 at a time
		if (startCursorString != null && !startCursorString.equals("")) {
			fetchOptions.startCursor(Cursor.fromWebSafeString(startCursorString)); // Where we left off
		}
		Query query = new Query(PARCEL_KIND) // We only care about Parceles
				.addSort(Parcel.TITLE, SortDirection.ASCENDING); // Use default Index "title"
		PreparedQuery preparedQuery = datastore.prepare(query);
		QueryResultIterator<Entity> results = preparedQuery.asQueryResultIterator(fetchOptions);

		List<Parcel> resultParceles = entitiesToParceles(results); // Retrieve and convert Entities
		Cursor cursor = results.getCursor(); // Where to start next time
		if (cursor != null && resultParceles.size() == 10) { // Are we paging? Save Cursor
			String cursorString = cursor.toWebSafeString(); // Cursors are WebSafe
			return new Result<>(resultParceles, cursorString);
		} else {
			return new Result<>(resultParceles);
		}
	}
	// [END listParceles]
}
