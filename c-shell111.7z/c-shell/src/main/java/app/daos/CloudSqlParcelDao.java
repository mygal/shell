
package app.daos;

import app.objects.Parcel;
import app.objects.Result;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// [START example]
public class CloudSqlParcelDao implements ParcelDao {
	// [START constructor]
	private String sqlUrl;

	/**
	 * A data access object for Bookshelf using a Google Cloud SQL server for
	 * storage.
	 */
	public CloudSqlParcelDao(final String url) throws SQLException {

		sqlUrl = url;
		final String createTableSql = "CREATE TABLE IF NOT EXISTS parcels2 ( id INT NOT NULL "
				+ "AUTO_INCREMENT, title VARCHAR(255), owner VARCHAR(255), startFrom VARCHAR(255), destination VARCHAR(255), "
				+ "description VARCHAR(255), imageUrl VARCHAR(255), PRIMARY KEY (id))";
		try (Connection conn = DriverManager.getConnection(sqlUrl)) {
			conn.createStatement().executeUpdate(createTableSql);
		}
	}

	// [END constructor]
	// [START create]
	@Override
  public Long createParcel(Parcel parcel) throws SQLException {
    final String createParcelString = "INSERT INTO parcels2 "
        + "(title, owner, startFrom, destination, description, imageUrl)"
        + "VALUES (?, ?, ?, ?, ?, ?)";
    try (Connection conn = DriverManager.getConnection(sqlUrl);
         final PreparedStatement createParcelStmt = conn.prepareStatement(createParcelString,
             Statement.RETURN_GENERATED_KEYS)) {
      createParcelStmt.setString(1, parcel.getTitle());
      createParcelStmt.setString(2, parcel.getOwner());
      createParcelStmt.setString(3, parcel.getStartFrom());
      createParcelStmt.setString(4, parcel.getDestination());
      createParcelStmt.setString(5, parcel.getDescription());
      createParcelStmt.setString(6, parcel.getImageUrl());
      createParcelStmt.executeUpdate();
      try (ResultSet keys = createParcelStmt.getGeneratedKeys()) {
        keys.next();
        return keys.getLong(1);
      }
    }
  }

	// [END create]
	// [START read]
	@Override
	public Parcel readParcel(Long parcelId) throws SQLException {
		final String readParcelString = "SELECT * FROM parcels2 WHERE id = ?";
		try (Connection conn = DriverManager.getConnection(sqlUrl);
				PreparedStatement readParcelStmt = conn.prepareStatement(readParcelString)) {
			readParcelStmt.setLong(1, parcelId);
			try (ResultSet keys = readParcelStmt.executeQuery()) {
				keys.next();
				return new Parcel.Builder().title(keys.getString(Parcel.TITLE)).owner(keys.getString(Parcel.OWNER))
						.startFrom(keys.getString(Parcel.START_FROM)).destination(keys.getString(Parcel.DESTINATION))
						.description(keys.getString(Parcel.DESCRIPTION)).imageUrl(keys.getString(Parcel.IMAGE_URL))
						.id(keys.getLong(Parcel.ID)).build();
			}
		}
	}

	// [END read]
	// [START update]
	@Override
	public void updateParcel(Parcel parcel) throws SQLException {
		final String updateParcelString = "UPDATE parcels2 SET title = ?, owner = ?, startFrom = ?, destination = ?, "
				+ "description = ?,  imageUrl = ? WHERE id = ?";
		try (Connection conn = DriverManager.getConnection(sqlUrl);
				PreparedStatement updateParcelStmt = conn.prepareStatement(updateParcelString)) {
			updateParcelStmt.setString(1, parcel.getTitle());
			updateParcelStmt.setString(2, parcel.getOwner());
			updateParcelStmt.setString(3, parcel.getStartFrom());
			updateParcelStmt.setString(4, parcel.getDestination());
			updateParcelStmt.setString(5, parcel.getDescription());
			updateParcelStmt.setString(7, parcel.getImageUrl());
			updateParcelStmt.setLong(8, parcel.getId());
			updateParcelStmt.executeUpdate();
		}
	}

	// [END update]
	// [START delete]
	@Override
	public void deleteParcel(Long parcelId) throws SQLException {
		final String deleteParcelString = "DELETE FROM parcels2 WHERE id = ?";
		try (Connection conn = DriverManager.getConnection(sqlUrl);
				PreparedStatement deleteParcelStmt = conn.prepareStatement(deleteParcelString)) {
			deleteParcelStmt.setLong(1, parcelId);
			deleteParcelStmt.executeUpdate();
		}
	}

	// [END delete]
	// [START listparceles]
	@Override
	public Result<Parcel> listParceles(String cursor) throws SQLException {
		int offset = 0;
		if (cursor != null && !cursor.equals("")) {
			offset = Integer.parseInt(cursor);
		}
		final String listParcelsString = "SELECT SQL_CALC_FOUND_ROWS title, owner, startFrom, destination, "
				+ "description, imageUrl, id FROM parcels2 ORDER BY title ASC " + "LIMIT 10 OFFSET ?";
		try (Connection conn = DriverManager.getConnection(sqlUrl);
				PreparedStatement listParcelsStmt = conn.prepareStatement(listParcelsString)) {
			listParcelsStmt.setInt(1, offset);
			List<Parcel> resultParcels = new ArrayList<>();
			try (ResultSet rs = listParcelsStmt.executeQuery()) {
				while (rs.next()) {
					Parcel parcel = new Parcel.Builder().title(rs.getString(Parcel.TITLE)).owner(rs.getString(Parcel.OWNER))
							.startFrom(rs.getString(Parcel.START_FROM)).destination(rs.getString(Parcel.DESTINATION))
							.description(rs.getString(Parcel.DESCRIPTION)).imageUrl(rs.getString(Parcel.IMAGE_URL))
							.id(rs.getLong(Parcel.ID)).build();
					resultParcels.add(parcel);
				}
			}
			try (ResultSet rs = conn.createStatement().executeQuery("SELECT FOUND_ROWS()")) {
				int totalNumRows = 0;
				if (rs.next()) {
					totalNumRows = rs.getInt(1);
				}
				if (totalNumRows > offset + 10) {
					return new Result<>(resultParcels, Integer.toString(offset + 10));
				} else {
					return new Result<>(resultParcels);
				}
			}
		}
	}
	// [END listparceles]
}
// [END example]
