
package app.daos;

import app.objects.Parcel;
import app.objects.Result;

import java.sql.SQLException;


public interface ParcelDao {
  Long createParcel(Parcel parcel) throws SQLException;

  Parcel readParcel(Long parcelId) throws SQLException;

  void updateParcel(Parcel parcel) throws SQLException;

  void deleteParcel(Long parcelId) throws SQLException;

  Result<Parcel> listParceles(String startCursor) throws SQLException;
}

