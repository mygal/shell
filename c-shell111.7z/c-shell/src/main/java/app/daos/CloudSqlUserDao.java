
package app.daos;

import app.objects.User;
import app.objects.Result;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// [START example]
public class CloudSqlUserDao implements UserDao {
  // [START constructor]
  private String sqlUrl;

  /**
   * A data access object for Bookshelf using a Google Cloud SQL server for storage.
   */
  public CloudSqlUserDao(final String url) throws SQLException {

    sqlUrl = url;
    final String createTableSql = "CREATE TABLE IF NOT EXISTS users2 ( id INT NOT NULL "
        + "AUTO_INCREMENT, name VARCHAR(255), password VARCHAR(255), role VARCHAR(255), "
        + "description VARCHAR(255), imageUrl VARCHAR(255), PRIMARY KEY (id))";
    
    try (Connection conn = DriverManager.getConnection(sqlUrl)) {
      conn.createStatement().executeUpdate(createTableSql);
    }
  }

  // [END constructor]
  // [START create]
  @Override
  public Long createUser(User user) throws SQLException {
    final String createUserString = "INSERT INTO users2 "
        + "(name, password, role, description, imageUrl) "
        + "VALUES (?, ?, ?, ?, ?)";
    try (Connection conn = DriverManager.getConnection(sqlUrl);
         final PreparedStatement createUserStmt = conn.prepareStatement(createUserString,
             Statement.RETURN_GENERATED_KEYS)) {
      createUserStmt.setString(1, user.getName());
      createUserStmt.setString(2, user.getPassword());
      createUserStmt.setString(3, user.getRole());
      createUserStmt.setString(4, user.getDescription());
      createUserStmt.setString(5, user.getImageUrl());
      createUserStmt.executeUpdate();
      try (ResultSet keys = createUserStmt.getGeneratedKeys()) {
        keys.next();
        return keys.getLong(1);
      }
    }
  }

  // [END create]
  // [START read]
  @Override
  public User readUser(Long userId) throws SQLException {
    final String readUserString = "SELECT * FROM users2 WHERE id = ?";
    try (Connection conn = DriverManager.getConnection(sqlUrl);
         PreparedStatement readUserStmt = conn.prepareStatement(readUserString)) {
      readUserStmt.setLong(1, userId);
      try (ResultSet keys = readUserStmt.executeQuery()) {
        keys.next();
        return new User.Builder()
            .name(keys.getString(User.NAME))
            .password(keys.getString(User.PASSWORD))
            .role(keys.getString(User.ROLE))
            .description(keys.getString(User.DESCRIPTION))
            .imageUrl(keys.getString(User.IMAGE_URL))
            .id(keys.getLong(User.ID))
            .build();
      }
    }
  }

  // [END read]
  // [START update]
  @Override
  public void updateUser(User user) throws SQLException {
    final String updateUserString = "UPDATE users2 SET name = ?, password = ?, role = ?, "
        + "description = ?, imageUrl = ? WHERE id = ?";
    try (Connection conn = DriverManager.getConnection(sqlUrl);
         PreparedStatement updateUserStmt = conn.prepareStatement(updateUserString)) {
      updateUserStmt.setString(1, user.getName());
      updateUserStmt.setString(2, user.getPassword());
      updateUserStmt.setString(3, user.getRole());
      updateUserStmt.setString(4, user.getDescription());
      updateUserStmt.setString(5, user.getImageUrl());
      updateUserStmt.setLong(6, user.getId());
      updateUserStmt.executeUpdate();
    }
  }

  // [END update]
  // [START delete]
  @Override
  public void deleteUser(Long userId) throws SQLException {
    final String deleteUserString = "DELETE FROM users2 WHERE id = ?";
    try (Connection conn = DriverManager.getConnection(sqlUrl);
         PreparedStatement deleteUserStmt = conn.prepareStatement(deleteUserString)) {
      deleteUserStmt.setLong(1, userId);
      deleteUserStmt.executeUpdate();
    }
  }

  // [END delete]
  // [START listuseres]
  @Override
  public Result<User> listUsers(String cursor) throws SQLException {
    int offset = 0;
    if (cursor != null && !cursor.equals("")) {
      offset = Integer.parseInt(cursor);
    }
    final String listUsersString = "SELECT SQL_CALC_FOUND_ROWS name, password, role, "
        + "description, imageUrl, id FROM users2 ORDER BY name ASC "
        + "LIMIT 10 OFFSET ?";
    try (Connection conn = DriverManager.getConnection(sqlUrl);
         PreparedStatement listUsersStmt = conn.prepareStatement(listUsersString)) {
      listUsersStmt.setInt(1, offset);
      List<User> resultUsers = new ArrayList<>();
      try (ResultSet rs = listUsersStmt.executeQuery()) {
        while (rs.next()) {
          User user = new User.Builder()
              .name(rs.getString(User.NAME))
              .password(rs.getString(User.PASSWORD))
              .role(rs.getString(User.ROLE))
              .description(rs.getString(User.DESCRIPTION))
              .imageUrl(rs.getString(User.IMAGE_URL))
              .id(rs.getLong(User.ID))
              .build();
          resultUsers.add(user);
        }
      }
      try (ResultSet rs = conn.createStatement().executeQuery("SELECT FOUND_ROWS()")) {
        int totalNumRows = 0;
        if (rs.next()) {
          totalNumRows = rs.getInt(1);
        }
        if (totalNumRows > offset + 10) {
          return new Result<>(resultUsers, Integer.toString(offset + 10));
        } else {
          return new Result<>(resultUsers);
        }
      }
    }
  }
  // [END listuseres]
}
// [END example]
