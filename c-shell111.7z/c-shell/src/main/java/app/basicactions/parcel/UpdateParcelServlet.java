
package app.basicactions.parcel;

import app.daos.ParcelDao;
import app.objects.Parcel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class UpdateParcelServlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ParcelDao dao = (ParcelDao) this.getServletContext().getAttribute("dao");
		try {
			Parcel parcel = dao.readParcel(Long.decode(req.getParameter("id")));
			req.setAttribute("parcel", parcel);
			req.setAttribute("action", "Edit");
			req.setAttribute("destination", "update");
			req.setAttribute("page", "form");
			req.getRequestDispatcher("/base.jsp").forward(req, resp);
		} catch (Exception e) {
			throw new ServletException("Error loading parcel for editing", e);
		}
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ParcelDao dao = (ParcelDao) this.getServletContext().getAttribute("dao");
		try {
			// [START parcelBuilder]
			Parcel parcel = new Parcel.Builder().owner(req.getParameter("owner"))
					.description(req.getParameter("description")).id(Long.decode(req.getParameter("id")))
					.title(req.getParameter("title")).build();
			// [END parcelBuilder]
			dao.updateParcel(parcel);
			resp.sendRedirect("/read?id=" + req.getParameter("id"));
		} catch (Exception e) {
			throw new ServletException("Error updating parcel", e);
		}
	}
}
