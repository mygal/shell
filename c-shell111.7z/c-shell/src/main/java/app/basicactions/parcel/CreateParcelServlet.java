
package app.basicactions.parcel;

import app.daos.ParcelDao;
import app.objects.Parcel;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class CreateParcelServlet extends HttpServlet {

  // [START setup]
  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
      IOException {
    req.setAttribute("action", "Add");          // Part of the Header in form.jsp
    req.setAttribute("destination", "create");  // The urlPattern to invoke (this Servlet)
    req.setAttribute("page", "form");           // Tells base.jsp to include form.jsp
    req.getRequestDispatcher("/base.jsp").forward(req, resp);
  }
  // [END setup]

  // [START formpost]
  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
      IOException {
    // [START parcelBuilder]
	  Parcel parcel = new Parcel.Builder()
        .owner(req.getParameter("owner"))   // form parameter
        .description(req.getParameter("description"))
        .title(req.getParameter("title"))
        .imageUrl(null)
        .build();
    // [END parcelBuilder]

	ParcelDao dao = (ParcelDao) this.getServletContext().getAttribute("dao");
    try {
      Long id = dao.createParcel(parcel);
      resp.sendRedirect("/read?id=" + id.toString());   // read what we just wrote
    } catch (Exception e) {
      throw new ServletException("Error creating parcel", e);
    }
  }
  // [END formpost]
}
