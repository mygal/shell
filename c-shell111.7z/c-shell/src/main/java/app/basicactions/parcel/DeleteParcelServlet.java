
package app.basicactions.parcel;

import app.daos.ParcelDao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// [START example]
@SuppressWarnings("serial")
public class DeleteParcelServlet extends HttpServlet {

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
      IOException {
    Long id = Long.decode(req.getParameter("id"));
    ParcelDao dao = (ParcelDao) this.getServletContext().getAttribute("dao");
    try {
      dao.deleteParcel(id);
      resp.sendRedirect("/parceles");
    } catch (Exception e) {
      throw new ServletException("Error deleting parcel", e);
    }
  }
}
