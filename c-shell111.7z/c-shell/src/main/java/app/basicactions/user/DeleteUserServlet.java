
package app.basicactions.user;

import app.daos.UserDao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// [START example]
@SuppressWarnings("serial")
public class DeleteUserServlet extends HttpServlet {

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
      IOException {
    Long id = Long.decode(req.getParameter("id"));
    UserDao dao = (UserDao) this.getServletContext().getAttribute("dao");
    try {
      dao.deleteUser(id);
      resp.sendRedirect("/parceles");
    } catch (Exception e) {
      throw new ServletException("Error deleting User", e);
    }
  }
}
