
package app.basicactions.user;

import app.daos.UserDao;
import app.daos.CloudSqlUserDao;
import app.daos.DatastoreUserDao;
import app.objects.User;
import app.objects.Result;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// [START example]
@SuppressWarnings("serial")
public class ListUserServlet extends HttpServlet {

  @Override
  public void init() throws ServletException {
	  UserDao dao = null;

    // Creates the DAO based on the Context Parameters !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    String storageType = this.getServletContext().getInitParameter("parcel.storageType");
    switch (storageType) {
      case "datastore":
        dao = new DatastoreUserDao();
        break;
      case "cloudsql":
        try {
          // Use this url when using dev appserver, but connecting to Cloud SQL
          String connect = this.getServletContext().getInitParameter("sql.urlRemote");
          if (connect.contains("localhost")) {
            // Use this url when using a local mysql server
            connect = this.getServletContext().getInitParameter("sql.urlLocal");
          } else if (System.getProperty("com.google.appengine.runtime.version")
              .startsWith("Google App Engine/")) {
            // Use this url when on App Engine, connecting to Cloud SQL.
            // Uses a special adapter because of the App Engine sandbox.
            connect = this.getServletContext().getInitParameter("sql.urlRemoteGAE");
          }
          dao = new CloudSqlUserDao(connect);
        } catch (SQLException e) {
          throw new ServletException("SQL error", e);
        }
        break;
      default:
        throw new IllegalStateException(
            "Invalid storage type. Check if parcel.storageType property is set.");
    }
    this.getServletContext().setAttribute("dao", dao);
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException,
      ServletException {
	UserDao dao = (UserDao) this.getServletContext().getAttribute("dao");
    String startCursor = req.getParameter("cursor");
    List<User> users = null;
    String endCursor = null;
    try {
      Result<User> result = dao.listUsers(startCursor);
      users = result.result;
      endCursor = result.cursor;
    } catch (Exception e) {
      throw new ServletException("Error listing users", e);
    }
    req.getSession().getServletContext().setAttribute("useres", users);
    StringBuilder userNames = new StringBuilder();
    for (User user : users) {
      userNames.append(user.getName() + " ");
    }
    req.setAttribute("cursor", endCursor);
    req.setAttribute("page", "list");
    req.getRequestDispatcher("/base.jsp").forward(req, resp);
  }
}
