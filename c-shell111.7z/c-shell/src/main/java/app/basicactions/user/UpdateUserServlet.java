
package app.basicactions.user;

import app.daos.UserDao;
import app.objects.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class UpdateUserServlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UserDao dao = (UserDao) this.getServletContext().getAttribute("dao");
		try {
			User user = dao.readUser(Long.decode(req.getParameter("id")));
			req.setAttribute("user", user);
			req.setAttribute("action", "Edit");
			req.setAttribute("destination", "update");
			req.setAttribute("page", "form");
			req.getRequestDispatcher("/base.jsp").forward(req, resp);
		} catch (Exception e) {
			throw new ServletException("Error loading user for editing ", e);
		}
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UserDao dao = (UserDao) this.getServletContext().getAttribute("dao");
		try {
			// [START parcelBuilder]
			User user = new User.Builder().name(req.getParameter("name"))
					.password(req.getParameter("password")).role(req.getParameter("role"))
					.description(req.getParameter("description")).id(Long.decode(req.getParameter("id")))
					.imageUrl(req.getParameter("imageUrl")).build();
			// [END parcelBuilder]
			dao.updateUser(user);
			resp.sendRedirect("/read?id=" + req.getParameter("id"));
		} catch (Exception e) {
			throw new ServletException("Error updating user ", e);
		}
	}
}
