
package app.basicactions.user;

import app.daos.UserDao;
import app.objects.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class CreateUserServlet extends HttpServlet {

	// [START setup]
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setAttribute("action", "Add"); // Part of the Header in form.jsp
		req.setAttribute("destination", "create"); // The urlPattern to invoke (this Servlet)
		req.setAttribute("page", "form"); // Tells base.jsp to include form.jsp
		req.getRequestDispatcher("/base.jsp").forward(req, resp);
	}
	// [END setup]

	// [START formpost]
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// [START userBuilder]
		User user = new User.Builder().name(req.getParameter("name")) // form parameter
				.password(req.getParameter("password")).role(req.getParameter("role"))
				.description(req.getParameter("description")).imageUrl(null).build();
		// [END userBuilder]

		UserDao dao = (UserDao) this.getServletContext().getAttribute("dao");
		try {
			Long id = dao.createUser(user);
			resp.sendRedirect("/read?id=" + id.toString()); // read what we just wrote
		} catch (Exception e) {
			throw new ServletException("Error creating user", e);
		}
	}
	// [END formpost]
}
