package app.servlets;

import java.util.ArrayList;
import java.util.List;

import app.entities.User;

public class Aaaaa {

	private static List<User> list;

	public static void main(String[] args) {
		list = new ArrayList<>();
		list.add(new User("123", "123"));
		list.add(new User("234", "234"));
		list.add(new User("345", "345"));

		System.out.println(list);
		System.out.println(isContainsName("123"));
		removeByName("123");
		System.out.println(list);
	}

	public static void removeByName(String name) {
		
		list.removeIf(x -> x.getName() == name);
	}

	public static boolean isContainsName(String name) {
		
		for (User elem : list) {
			if (elem.getName() == name)
				return true;
		}
		return false;

	}
}
