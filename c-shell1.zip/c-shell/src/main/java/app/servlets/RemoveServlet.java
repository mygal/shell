package app.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.entities.User;
import app.model.Model;

@WebServlet("/Remove")
public class RemoveServlet extends HttpServlet {

	public RemoveServlet() {
		super();
	}

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Model list = Model.getInstance();
		List<String> names = list.list();
		req.setAttribute("userNames", names);

		RequestDispatcher requestDispatcher = req.getRequestDispatcher("views/remove.jsp");
		requestDispatcher.forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String name = req.getParameter("name");
		Model list = Model.getInstance();

		if (list.isContainsName(name)) {

			list.removeByName(name);
			req.setAttribute("userRemoving", "removed");

		} else {
			req.setAttribute("userRemoving", "noSuchUser");
		}

		List<String> names = list.list();
		req.setAttribute("userNames", names);
		doGet(req, resp);
	}
}
