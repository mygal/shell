package app.model;

import app.entities.User;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Model {
	private static Model instance = new Model();

	private List<User> list;

	public static Model getInstance() {
		return instance;
	}

	private Model() {
		list = new ArrayList<>();
	}

	public void add(User user) {
		list.add(user);
	}

	public void remove(User user) {
		list.remove(user);
	}

	@Override
	public String toString() {
		return "Model [list=" + list + "]";
	}

	public void removeByName(String name) {
		// Java 8
		list.removeIf(x -> x.getName().equals(name));
	}

	public boolean isContainsName(String name) {
		for (User elem : list) {
			if (elem.getName().equals(name))
				return true;
		}
		return false;
	}

	public List<String> list() {
		return list.stream().map(User::getName).collect(Collectors.toList());
	}
}
